package ru.wp.lesson8.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import ru.wp.lesson8.services.ReservationService;

@Controller
public class IndexPage {
    private final ReservationService reservationService;

    public IndexPage(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    @GetMapping({"/", "/index"})
    public String get(Model model) {
        model.addAttribute("reservations", reservationService.all());
        return "IndexPage";
    }
}
