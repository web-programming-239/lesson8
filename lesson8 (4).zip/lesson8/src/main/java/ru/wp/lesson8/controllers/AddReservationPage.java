package ru.wp.lesson8.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import ru.wp.lesson8.model.Reservation;
import ru.wp.lesson8.services.ReservationService;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

@Controller
public class AddReservationPage {
    private final ReservationService reservationService;

    public AddReservationPage(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    @GetMapping("/add_reservation")
    public String get() {
        return "AddReservationPage";
    }

    @PostMapping("/add_reservation")
    public String post(
            Model httpSession,
            @ModelAttribute("roomNumber") String roomNumber,
            @ModelAttribute("startTime") String startTime,
            @ModelAttribute("endTime") String endTime) {

        if (roomNumber.length() == 0 || startTime.length() == 0 || endTime.length() == 0) {
            httpSession.addAttribute("message", "Заполните все поля");
            return "AddReservationPage";
        }

        Reservation r = new Reservation();

        r.setRoomNumber(roomNumber);
        r.setStartTime(LocalTime.parse(startTime, DateTimeFormatter.ofPattern("HH:mm")));
        r.setEndTime(LocalTime.parse(endTime, DateTimeFormatter.ofPattern("HH:mm")));

        reservationService.save(r);

        return "redirect:";
    }
}
