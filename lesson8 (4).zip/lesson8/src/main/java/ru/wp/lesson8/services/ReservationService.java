package ru.wp.lesson8.services;

import org.springframework.stereotype.Service;
import ru.wp.lesson8.model.Reservation;
import ru.wp.lesson8.repository.ReservationRepository;

import java.util.List;

@Service
public class ReservationService {

    private final ReservationRepository reservationRepository;

    public ReservationService(ReservationRepository reservationRepository) {
        this.reservationRepository = reservationRepository;
    }

    public void save(Reservation reservation) {
        reservationRepository.save(reservation);
    }

    public List<Reservation> all() {
        return reservationRepository.findAll();
    }
}
