## Домашнее задание

- Помимо номера кабинета, время начала-конца бронирования, в IndexPage также отображайте id каждой регистрации

- Обратите внимание, что при создании резервации отсутствует форма для ввода ФИО преподавателя. Исправьте это и не
  забудьте отобразить изменения в IndexPage.

:NOTE: Не пытайтесь создавать новые сущности и таблицы для них, под ФИО достаточно подразумевать строку вида "Имя
Фамилия".

- Помимо добавления строкового поля ФИО в резервации, добавьте также поле типа Date - дату самой резервации.

- Расширьте функционал. Помимо добавления бронирования, реализуйте также возможность удаления бронирования.

:NOTE: Весьма оптимальным методом решения данного задания будет удаление из таблицы по id.

Пример:

Пусть у нас есть сущность Car (машина))) с двумя полями: мощность и цвет.

```java
import jakarta.persistence.*;

@Entity
@Table(name = "car")
public class Car {

    @Column(name = "power")
    private int power;

    @Column(name = "color")
    private Color color;

    // todo: getters & setters....
}
``` 

Магическим образом, Spring сам создает бд с таблицей "car". Но что если мы захотим удалить элемент из таблицы с какой-нибудь мощностью
"power", и цветом "color".

Хорошим решением будет при реализации CarRepository создать метод

```java
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface CarRepository extends JpaRepository<Car, Long> {
    
  @Query(
          value = "DELETE from car WHERE power=?1 and color=?2" ,
          nativeQuery = true
  )
  void remove(int power, Color color);
}
```

Тогда, при последующей реализации и вызова этого метода, будет отправляться SQL запрос, удаляющий элемент в таблице "cars" с теми параметрами, которые вы передали в метод. 


